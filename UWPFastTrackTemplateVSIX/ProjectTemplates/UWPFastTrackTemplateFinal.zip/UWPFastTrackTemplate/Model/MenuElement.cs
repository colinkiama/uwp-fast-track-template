﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $ext_safeprojectname$.Model
{
    public class MenuElement
    {
        public string Title { get; set; }
        public string Tag { get; set; }
        public string Icon { get; set; }
    }
}
