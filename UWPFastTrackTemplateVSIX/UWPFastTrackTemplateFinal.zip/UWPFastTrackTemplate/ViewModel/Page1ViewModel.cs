﻿using System;
using System.Collections.Generic;
using System.Text;
using $ext_safeprojectname$.Services;

namespace $ext_safeprojectname$.ViewModel
{
    public class Page1ViewModel : NavigatableViewModelBase
    {
        public Page1ViewModel(INavigationService navigationService) : base(navigationService)
        {
        }
    }
}
