﻿using System;
using System.Collections.Generic;
using System.Text;
using $ext_safeprojectname$.Services;

namespace $ext_safeprojectname$.ViewModel
{
    public class SettingsViewModel : NavigatableViewModelBase
    {
        public SettingsViewModel(INavigationService navigationService) : base(navigationService)
        {
        }
    }
}
